struct drv_req {
	unsigned long offset;
};
